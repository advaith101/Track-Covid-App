module.exports = {
    mongoURI: 'mongodb+srv://asekharan7:free2rhyme@trackcovid-ukzbi.mongodb.net/test?retryWrites=true&w=majority'
}