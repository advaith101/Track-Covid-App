
# Run Scripts

## To run locally for Dev env

``npm run dev``



# Heroku Details

## Login

``heroku login``

opens up browser for login

## To check Logs

``heroku logs --app esratrackcovid -t``